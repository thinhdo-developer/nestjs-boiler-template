import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { I18nModule, I18nJsonLoader } from 'nestjs-i18n';
import { APP_GUARD } from '@nestjs/core';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DatabaseModule } from '@database/database.module';
import { LoggerModule } from './logger/logger.module';
import { HealthModule } from './health/health.module';
import { MailModule } from './mail/mail.module';
import { StorageModule } from './storage/storage.module';
import { CacheModule } from './cache/cache.module';
import { AuthModule } from '@modules/auth/auth.module';
import { UsersModule } from '@modules/users/users.module';
import { UploadModule } from '@modules/upload/upload.module';
import { CorrelationIdMiddleware } from '@common/middlewares/correlation-id.middleware';
import { CustomThrottlerGuard } from '@common/guards/throttler.guard';
import { envValidationSchema } from '@config/env.validation';
import { i18nConfig } from './i18n/i18n.config';
import appConfig from '@config/app.config';
import databaseConfig from '@config/database.config';

@Module({
  imports: [
    // ── Config ────────────────────────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, databaseConfig],
      envFilePath: [`.env.${process.env.NODE_ENV || 'development'}`, '.env'],
      validationSchema: envValidationSchema,
    }),

    // ── Cross-cutting ─────────────────────────────────────────────────────────
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    EventEmitterModule.forRoot({ wildcard: false, delimiter: '.', global: true }),
    I18nModule.forRoot({ ...i18nConfig, loader: I18nJsonLoader }),

    // ── Infrastructure (interface-based, swap via useClass) ───────────────────
    LoggerModule, // Pino
    DatabaseModule, // TypeORM + PostgreSQL
    MailModule, // IMailService → NodemailerService (swap → SendGridService)
    StorageModule, // IStorageService → LocalStorageService (swap → S3StorageService)
    CacheModule, // ICacheService → driven by CACHE_DRIVER env (memory | redis)

    // ── Ops ───────────────────────────────────────────────────────────────────
    HealthModule,

    // ── Features ──────────────────────────────────────────────────────────────
    AuthModule,
    UsersModule,
    UploadModule,
  ],
  controllers: [AppController],
  providers: [AppService, { provide: APP_GUARD, useClass: CustomThrottlerGuard }],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(CorrelationIdMiddleware).forRoutes('*');
  }
}
