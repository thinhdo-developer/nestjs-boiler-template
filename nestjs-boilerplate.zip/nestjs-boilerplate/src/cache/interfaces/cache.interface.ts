export const CACHE_SERVICE = Symbol('CACHE_SERVICE');

export interface CacheSetOptions {
  /** TTL in seconds. Omit for no expiry. */
  ttl?: number;
}

/**
 * Cache abstraction — swap Memory ↔ Redis ↔ Memcached
 * by changing one line in CacheModule.
 */
export interface ICacheService {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, options?: CacheSetOptions): Promise<void>;
  del(key: string): Promise<void>;
  /** Delete all keys matching a pattern, e.g. 'users:*' */
  delByPattern(pattern: string): Promise<void>;
  /** Check existence without fetching value */
  has(key: string): Promise<boolean>;
  /** Wrap a factory in cache: return cached value or compute + store */
  wrap<T>(key: string, factory: () => Promise<T>, options?: CacheSetOptions): Promise<T>;
}
