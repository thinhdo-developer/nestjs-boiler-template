import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { CACHE_SERVICE } from './interfaces/cache.interface';
import { MemoryCacheService } from './implementations/memory.service';
import { RedisCacheService } from './implementations/redis.service';

/**
 * To switch cache provider:
 *   1. Change the `useClass` logic below (or set CACHE_DRIVER env var)
 *   2. No consumer code changes required
 *
 * CACHE_DRIVER=memory  → MemoryCacheService (default, no infra needed)
 * CACHE_DRIVER=redis   → RedisCacheService  (requires Redis)
 */
@Module({
  imports: [ConfigModule],
  providers: [
    MemoryCacheService,
    RedisCacheService,
    {
      provide: CACHE_SERVICE,
      inject: [ConfigService, MemoryCacheService, RedisCacheService],
      useFactory: (config: ConfigService, memory: MemoryCacheService, redis: RedisCacheService) => {
        const driver = config.get<string>('CACHE_DRIVER', 'memory');
        return driver === 'redis' ? redis : memory;
      },
    },
  ],
  exports: [CACHE_SERVICE],
})
export class CacheModule {}
