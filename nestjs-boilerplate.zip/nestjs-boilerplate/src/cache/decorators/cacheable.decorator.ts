import { Inject } from '@nestjs/common';
import { CACHE_SERVICE, ICacheService } from '../interfaces/cache.interface';

/**
 * Method decorator that caches the return value.
 * Key is built from the method name + serialized arguments by default.
 *
 * @example
 * @Cacheable({ key: (id: string) => `users:${id}`, ttl: 300 })
 * async findOne(id: string): Promise<User> { ... }
 */
export function Cacheable(options: {
  key: string | ((...args: any[]) => string);
  ttl?: number;
}): MethodDecorator {
  const injectCache = Inject(CACHE_SERVICE);

  return (target: any, propertyKey: string | symbol, descriptor: PropertyDescriptor) => {
    // Inject the cache service into the class prototype
    injectCache(target, '_cacheService');

    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      const cacheService: ICacheService = this._cacheService;
      if (!cacheService) return originalMethod.apply(this, args);

      const cacheKey = typeof options.key === 'function' ? options.key(...args) : options.key;

      return cacheService.wrap(cacheKey, () => originalMethod.apply(this, args), {
        ttl: options.ttl,
      });
    };

    return descriptor;
  };
}

/**
 * Method decorator that invalidates cache keys after the method completes.
 *
 * @example
 * @CacheInvalidate({ keys: (id: string) => [`users:${id}`, 'users:list'] })
 * async update(id: string, dto: UpdateUserDto): Promise<User> { ... }
 */
export function CacheInvalidate(options: {
  keys: string[] | ((...args: any[]) => string[]);
}): MethodDecorator {
  const injectCache = Inject(CACHE_SERVICE);

  return (target: any, _propertyKey: string | symbol, descriptor: PropertyDescriptor) => {
    injectCache(target, '_cacheService');

    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      const result = await originalMethod.apply(this, args);

      const cacheService: ICacheService = this._cacheService;
      if (cacheService) {
        const keys = typeof options.keys === 'function' ? options.keys(...args) : options.keys;
        await Promise.all(keys.map((k) => cacheService.del(k)));
      }

      return result;
    };

    return descriptor;
  };
}
