import { Injectable } from '@nestjs/common';
import { MailerService } from '@nestjs-modules/mailer';
import { IMailService, SendMailOptions } from '../interfaces/mail.interface';
import { AppLogger } from '@app/logger/app-logger.service';

@Injectable()
export class NodemailerService implements IMailService {
  constructor(
    private readonly mailer: MailerService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext(NodemailerService.name);
  }

  async send(options: SendMailOptions): Promise<void> {
    try {
      await this.mailer.sendMail({
        to: options.to,
        subject: options.subject,
        template: options.template,
        context: options.context,
      });
    } catch (err) {
      this.logger.error('Failed to send email', err as Error, {
        to: options.to,
        subject: options.subject,
      });
    }
  }

  async sendWelcome(to: string, firstName: string): Promise<void> {
    await this.send({ to, subject: 'Welcome!', template: 'welcome', context: { firstName } });
  }

  async sendEmailVerification(to: string, token: string): Promise<void> {
    const verifyUrl = `${process.env.APP_URL}/auth/verify-email?token=${token}`;
    await this.send({
      to,
      subject: 'Verify your email address',
      template: 'verify-email',
      context: { verifyUrl },
    });
  }

  async sendPasswordReset(to: string, resetUrl: string): Promise<void> {
    await this.send({
      to,
      subject: 'Password Reset Request',
      template: 'password-reset',
      context: { resetUrl },
    });
  }
}
