import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IMailService, SendMailOptions } from '../interfaces/mail.interface';
import { AppLogger } from '@app/logger/app-logger.service';

/**
 * SendGrid implementation.
 * To activate: change `useClass` in MailModule to SendGridService
 * and add SENDGRID_API_KEY to .env
 *
 * Install: npm install @sendgrid/mail
 */
@Injectable()
export class SendGridService implements IMailService {
  // private readonly client: SendGrid;  ← uncomment after installing @sendgrid/mail

  constructor(
    private readonly configService: ConfigService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext(SendGridService.name);
    // const apiKey = this.configService.get<string>('SENDGRID_API_KEY');
    // sendgrid.setApiKey(apiKey);
  }

  async send(_options: SendMailOptions): Promise<void> {
    this.logger.warn('SendGridService.send() — stub, install @sendgrid/mail to activate');
    // await sendgrid.send({ to: _options.to, subject: _options.subject, ... });
  }

  async sendWelcome(to: string, firstName: string): Promise<void> {
    await this.send({ to, subject: 'Welcome!', template: 'welcome', context: { firstName } });
  }

  async sendEmailVerification(to: string, token: string): Promise<void> {
    const verifyUrl = `${process.env.APP_URL}/auth/verify-email?token=${token}`;
    await this.send({
      to,
      subject: 'Verify your email',
      template: 'verify-email',
      context: { verifyUrl },
    });
  }

  async sendPasswordReset(to: string, resetUrl: string): Promise<void> {
    await this.send({
      to,
      subject: 'Password Reset',
      template: 'password-reset',
      context: { resetUrl },
    });
  }
}
