import { Module } from '@nestjs/common';
import { MailerModule } from '@nestjs-modules/mailer';
import { HandlebarsAdapter } from '@nestjs-modules/mailer/dist/adapters/handlebars.adapter';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { join } from 'path';
import { MAIL_SERVICE } from './interfaces/mail.interface';
import { NodemailerService } from './implementations/nodemailer.service';
// import { SendGridService } from './implementations/sendgrid.service'; // ← swap here

/**
 * To switch mail provider:
 *   1. Change `useClass` below to SendGridService (or any new implementation)
 *   2. Update .env with the new provider's credentials
 *   3. No consumer code changes required
 */
@Module({
  imports: [
    MailerModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        transport: {
          host: config.get('MAIL_HOST'),
          port: config.get('MAIL_PORT', 587),
          auth: { user: config.get('MAIL_USER'), pass: config.get('MAIL_PASSWORD') },
        },
        defaults: { from: config.get('MAIL_FROM', '"No Reply" <no-reply@example.com>') },
        template: {
          dir: join(__dirname, 'templates'),
          adapter: new HandlebarsAdapter(),
          options: { strict: true },
        },
      }),
    }),
  ],
  providers: [NodemailerService, { provide: MAIL_SERVICE, useClass: NodemailerService }],
  exports: [MAIL_SERVICE],
})
export class MailModule {}
