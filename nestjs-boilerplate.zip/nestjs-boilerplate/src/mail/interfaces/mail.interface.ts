/**
 * Injection token — use this when injecting IMailService.
 *
 * @example
 * @Inject(MAIL_SERVICE) private readonly mail: IMailService
 */
export const MAIL_SERVICE = Symbol('MAIL_SERVICE');

export interface SendMailOptions {
  to: string | string[];
  subject: string;
  /** Handlebars template name (no extension) */
  template: string;
  context?: Record<string, unknown>;
}

/**
 * Mail abstraction — swap Nodemailer ↔ SendGrid ↔ Resend ↔ SES
 * by changing one line in MailModule.
 */
export interface IMailService {
  send(options: SendMailOptions): Promise<void>;
  sendWelcome(to: string, firstName: string): Promise<void>;
  sendEmailVerification(to: string, token: string): Promise<void>;
  sendPasswordReset(to: string, resetUrl: string): Promise<void>;
}
