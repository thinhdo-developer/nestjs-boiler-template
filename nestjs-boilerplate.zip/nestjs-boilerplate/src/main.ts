import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { Logger } from 'nestjs-pino';
import { I18nValidationPipe } from 'nestjs-i18n';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from '@common/filters/http-exception.filter';
import { I18nValidationExceptionFilter } from '@common/filters/i18n-validation-exception.filter';
import { ResponseInterceptor } from '@common/interceptors/response.interceptor';
// Note: HTTP request/response logging is handled automatically by pino-http middleware
// (registered via LoggerModule). The manual LoggingInterceptor is no longer needed.

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });

  // Use Pino as NestJS's built-in logger
  app.useLogger(app.get(Logger));

  const configService = app.get(ConfigService);
  const port = configService.get<number>('app.port', 3000);
  const apiPrefix = configService.get<string>('app.apiPrefix', 'api/v1');
  const swaggerEnabled = configService.get<boolean>('app.swaggerEnabled', true);

  // Security
  app.use(helmet());
  app.enableCors();

  // Global prefix
  app.setGlobalPrefix(apiPrefix);

  // Global pipes
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
    new I18nValidationPipe(), // translates class-validator messages
  );

  // Global filters
  app.useGlobalFilters(new HttpExceptionFilter(), new I18nValidationExceptionFilter());

  // Global interceptors
  app.useGlobalInterceptors(new ResponseInterceptor());

  // Swagger — full configuration with bearer auth
  if (swaggerEnabled) {
    const config = new DocumentBuilder()
      .setTitle('NestJS Boilerplate API')
      .setDescription(
        `
## Authentication
Most endpoints require a **Bearer JWT** token.

1. \`POST /auth/register\` or \`POST /auth/login\` to get a token
2. Click **Authorize** and paste it in

## Localization
Pass \`Accept-Language: ko\` header or \`?lang=ko\` query param for Korean responses.
      `.trim(),
      )
      .setVersion('1.0')
      .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' })
      .addTag('Auth', 'Authentication endpoints')
      .addTag('Users', 'User management')
      .addTag('Health', 'Health checks for Kubernetes probes')
      .build();

    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup(`${apiPrefix}/docs`, app, document, {
      swaggerOptions: {
        persistAuthorization: true, // remember token across page refreshes
        tagsSorter: 'alpha',
        operationsSorter: 'alpha',
      },
    });
  }

  await app.listen(port);
  console.log(`🚀 App running on: http://localhost:${port}/${apiPrefix}`);
  if (swaggerEnabled) {
    console.log(`📚 Swagger docs: http://localhost:${port}/${apiPrefix}/docs`);
  }
}

bootstrap();
