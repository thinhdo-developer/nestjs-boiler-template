import { Throttle, SkipThrottle } from '@nestjs/throttler';

/**
 * Apply strict rate limiting to sensitive routes (e.g. login, register).
 * Usage: @StrictThrottle()  →  5 requests / 60 seconds
 */
export const StrictThrottle = () => Throttle({ default: { limit: 5, ttl: 60000 } });

/**
 * Skip throttling for internal/health routes.
 */
export { SkipThrottle };
