import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';

export const CORRELATION_ID_HEADER = 'X-Correlation-ID';

/**
 * Attaches a correlation ID to every request.
 * Uses the incoming header if present (for service-to-service calls), otherwise generates one.
 * The ID is added to the response headers so clients can trace their request.
 */
@Injectable()
export class CorrelationIdMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    const correlationId = (req.headers[CORRELATION_ID_HEADER.toLowerCase()] as string) ?? uuidv4();

    req['correlationId'] = correlationId;
    res.setHeader(CORRELATION_ID_HEADER, correlationId);

    next();
  }
}
