import {
  Repository,
  FindManyOptions,
  FindOneOptions,
  DeepPartial,
  SelectQueryBuilder,
} from 'typeorm';
import { NotFoundException } from '@nestjs/common';
import { BaseEntity } from '@common/entities/base.entity';
import { PaginationDto } from '@common/pagination/pagination.dto';
import { PaginatedResponse } from '@common/pagination/paginated-response.dto';

/**
 * Generic base repository — extend this for every entity.
 *
 * @example
 * @Injectable()
 * export class ProductsRepository extends BaseRepository<Product> {
 *   constructor(@InjectRepository(Product) repo: Repository<Product>) {
 *     super(repo);
 *   }
 * }
 */
export abstract class BaseRepository<T extends BaseEntity> {
  constructor(protected readonly repository: Repository<T>) {}

  // ── Create ──────────────────────────────────────────────────────────────────

  create(data: DeepPartial<T>): T {
    return this.repository.create(data);
  }

  async save(entity: T): Promise<T> {
    return this.repository.save(entity);
  }

  async createAndSave(data: DeepPartial<T>): Promise<T> {
    const entity = this.repository.create(data);
    return this.repository.save(entity);
  }

  // ── Read ────────────────────────────────────────────────────────────────────

  async findAll(options?: FindManyOptions<T>): Promise<T[]> {
    return this.repository.find(options);
  }

  async findOne(options: FindOneOptions<T>): Promise<T | null> {
    return this.repository.findOne(options);
  }

  async findOneOrFail(options: FindOneOptions<T>, errorMessage?: string): Promise<T> {
    const entity = await this.repository.findOne(options);
    if (!entity) {
      throw new NotFoundException(errorMessage ?? 'Resource not found');
    }
    return entity;
  }

  async findById(id: string, options?: FindOneOptions<T>): Promise<T | null> {
    return this.repository.findOne({ where: { id } as any, ...options });
  }

  async findByIdOrFail(id: string, errorMessage?: string): Promise<T> {
    return this.findOneOrFail({ where: { id } as any }, errorMessage);
  }

  async count(options?: FindManyOptions<T>): Promise<number> {
    return this.repository.count(options);
  }

  async exists(options: FindManyOptions<T>): Promise<boolean> {
    const count = await this.repository.count(options);
    return count > 0;
  }

  // ── Pagination ───────────────────────────────────────────────────────────────

  async paginate(
    pagination: PaginationDto,
    options?: FindManyOptions<T>,
  ): Promise<PaginatedResponse<T>> {
    const { page, limit } = pagination;
    const skip = (page - 1) * limit;

    const [data, total] = await this.repository.findAndCount({
      ...options,
      skip,
      take: limit,
    });

    return new PaginatedResponse(data, total, page, limit);
  }

  async paginateQueryBuilder(
    qb: SelectQueryBuilder<T>,
    pagination: PaginationDto,
  ): Promise<PaginatedResponse<T>> {
    const { page, limit } = pagination;
    const [data, total] = await qb
      .skip((page - 1) * limit)
      .take(limit)
      .getManyAndCount();

    return new PaginatedResponse(data, total, page, limit);
  }

  // ── Update ──────────────────────────────────────────────────────────────────

  async update(entity: T, data: DeepPartial<T>): Promise<T> {
    Object.assign(entity, data);
    return this.repository.save(entity);
  }

  // ── Delete ──────────────────────────────────────────────────────────────────

  async softDelete(entity: T): Promise<void> {
    await this.repository.softRemove(entity);
  }

  async hardDelete(entity: T): Promise<void> {
    await this.repository.remove(entity);
  }

  // ── Query Builder ────────────────────────────────────────────────────────────

  createQueryBuilder(alias: string): SelectQueryBuilder<T> {
    return this.repository.createQueryBuilder(alias);
  }
}
