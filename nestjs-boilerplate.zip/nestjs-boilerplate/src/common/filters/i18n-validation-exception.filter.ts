import { ArgumentsHost, Catch, ExceptionFilter, HttpStatus } from '@nestjs/common';
import { I18nValidationException } from 'nestjs-i18n';
import { Response } from 'express';

/**
 * Catches validation errors and returns translated messages.
 * Apply alongside HttpExceptionFilter in main.ts.
 */
@Catch(I18nValidationException)
export class I18nValidationExceptionFilter implements ExceptionFilter {
  catch(exception: I18nValidationException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest();

    response.status(HttpStatus.UNPROCESSABLE_ENTITY).json({
      success: false,
      statusCode: HttpStatus.UNPROCESSABLE_ENTITY,
      timestamp: new Date().toISOString(),
      path: request.url,
      message: exception.errors.flatMap((e) => Object.values(e.constraints ?? {})),
    });
  }
}
