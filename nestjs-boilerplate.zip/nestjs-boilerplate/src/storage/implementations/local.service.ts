import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IStorageService, UploadedFile, UploadOptions } from '../interfaces/storage.interface';
import { AppLogger } from '@app/logger/app-logger.service';
import * as fs from 'fs/promises';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class LocalStorageService implements IStorageService {
  private readonly uploadDir: string;
  private readonly baseUrl: string;

  constructor(
    private readonly config: ConfigService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext(LocalStorageService.name);
    this.uploadDir = config.get('STORAGE_LOCAL_DIR', 'uploads');
    this.baseUrl = config.get('APP_URL', 'http://localhost:3000');
  }

  async upload(file: Express.Multer.File, options: UploadOptions = {}): Promise<UploadedFile> {
    const folder = options.folder ?? 'general';
    const ext = path.extname(file.originalname);
    const filename = options.filename ?? `${uuidv4()}${ext}`;
    const key = `${folder}/${filename}`;
    const dest = path.join(this.uploadDir, folder);

    await fs.mkdir(dest, { recursive: true });
    await fs.writeFile(path.join(dest, filename), file.buffer);

    this.logger.info('File saved locally', { key, size: file.size });

    return {
      url: `${this.baseUrl}/files/${key}`,
      key,
      filename: file.originalname,
      mimeType: file.mimetype,
      size: file.size,
    };
  }

  async delete(key: string): Promise<void> {
    const filePath = path.join(this.uploadDir, key);
    await fs.unlink(filePath).catch(() => this.logger.warn('File not found for deletion', { key }));
  }

  async getSignedUrl(key: string, _expiresInSeconds?: number): Promise<string> {
    // Local storage has no signed URLs — return a direct link
    return `${this.baseUrl}/files/${key}`;
  }
}
