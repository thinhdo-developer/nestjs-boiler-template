import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IStorageService, UploadedFile, UploadOptions } from '../interfaces/storage.interface';
import { AppLogger } from '@app/logger/app-logger.service';
import { v4 as uuidv4 } from 'uuid';
import * as path from 'path';

/**
 * AWS S3 / S3-compatible (R2, MinIO) implementation.
 *
 * To activate:
 *   1. npm install @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
 *   2. Uncomment the imports and implementation below
 *   3. Change `useClass` in StorageModule to S3StorageService
 *   4. Add S3_* variables to .env
 */
@Injectable()
export class S3StorageService implements IStorageService {
  // private readonly s3: S3Client;
  private readonly bucket: string;
  private readonly region: string;

  constructor(
    private readonly config: ConfigService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext(S3StorageService.name);
    this.bucket = config.get('S3_BUCKET', '');
    this.region = config.get('S3_REGION', 'us-east-1');

    // this.s3 = new S3Client({
    //   region: this.region,
    //   endpoint: config.get('S3_ENDPOINT'), // for R2/MinIO
    //   credentials: {
    //     accessKeyId: config.get('S3_ACCESS_KEY'),
    //     secretAccessKey: config.get('S3_SECRET_KEY'),
    //   },
    // });
  }

  async upload(file: Express.Multer.File, options: UploadOptions = {}): Promise<UploadedFile> {
    const folder = options.folder ?? 'general';
    const ext = path.extname(file.originalname);
    const filename = options.filename ?? `${uuidv4()}${ext}`;
    const key = `${folder}/${filename}`;

    // await this.s3.send(new PutObjectCommand({
    //   Bucket: this.bucket,
    //   Key: key,
    //   Body: file.buffer,
    //   ContentType: file.mimetype,
    //   ACL: options.isPublic ? 'public-read' : 'private',
    // }));

    this.logger.info('File uploaded to S3', { key, bucket: this.bucket });

    return {
      url: `https://${this.bucket}.s3.${this.region}.amazonaws.com/${key}`,
      key,
      filename: file.originalname,
      mimeType: file.mimetype,
      size: file.size,
    };
  }

  async delete(key: string): Promise<void> {
    // await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
    this.logger.info('File deleted from S3', { key });
  }

  async getSignedUrl(key: string, _expiresInSeconds = 3600): Promise<string> {
    // const command = new GetObjectCommand({ Bucket: this.bucket, Key: key });
    // return getSignedUrl(this.s3, command, { expiresIn: _expiresInSeconds });
    return `https://${this.bucket}.s3.${this.region}.amazonaws.com/${key}?signed=stub`;
  }
}
