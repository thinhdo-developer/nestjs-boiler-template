export const STORAGE_SERVICE = Symbol('STORAGE_SERVICE');

export interface UploadedFile {
  /** Public URL or path to access the file */
  url: string;
  /** Storage key / path (used to delete later) */
  key: string;
  /** Original filename */
  filename: string;
  /** MIME type */
  mimeType: string;
  /** File size in bytes */
  size: number;
}

export interface UploadOptions {
  /** Destination folder/prefix */
  folder?: string;
  /** Override the generated filename */
  filename?: string;
  /** Whether the file should be publicly accessible */
  isPublic?: boolean;
}

/**
 * Storage abstraction — swap Local ↔ S3 ↔ GCS ↔ Cloudflare R2
 * by changing one line in StorageModule.
 */
export interface IStorageService {
  upload(file: Express.Multer.File, options?: UploadOptions): Promise<UploadedFile>;
  delete(key: string): Promise<void>;
  getSignedUrl(key: string, expiresInSeconds?: number): Promise<string>;
}
