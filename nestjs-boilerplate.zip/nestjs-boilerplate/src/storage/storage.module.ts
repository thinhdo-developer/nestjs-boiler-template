import { Module } from '@nestjs/common';
import { STORAGE_SERVICE } from './interfaces/storage.interface';
import { LocalStorageService } from './implementations/local.service';
// import { S3StorageService } from './implementations/s3.service'; // ← swap here

/**
 * To switch storage provider:
 *   1. Change `useClass` below to S3StorageService (or any new implementation)
 *   2. Update .env with the new provider's credentials
 *   3. No consumer code changes required
 */
@Module({
  providers: [LocalStorageService, { provide: STORAGE_SERVICE, useClass: LocalStorageService }],
  exports: [STORAGE_SERVICE],
})
export class StorageModule {}
