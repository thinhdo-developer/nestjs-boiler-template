import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './strategies/jwt.strategy';
import { JwtAuthGuard } from '@common/guards/jwt-auth.guard';
import { Token } from './entities/token.entity';
import { UsersModule } from '@modules/users/users.module';
import { MailModule } from '@app/mail/mail.module';
import { FirebaseModule } from '@app/firebase/firebase.module';
import { UserRegisteredListener } from './listeners/user-registered.listener';

@Module({
  imports: [
    UsersModule,
    MailModule,
    FirebaseModule,
    PassportModule,
    TypeOrmModule.forFeature([Token]),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: config.get('JWT_ACCESS_EXPIRATION', '15m') },
      }),
    }),
  ],
  providers: [
    AuthService,
    JwtStrategy,
    UserRegisteredListener,
    { provide: APP_GUARD, useClass: JwtAuthGuard },
  ],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
