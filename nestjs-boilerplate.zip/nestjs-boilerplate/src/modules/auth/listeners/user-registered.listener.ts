import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { MAIL_SERVICE, IMailService } from '@app/mail/interfaces/mail.interface';
import { AppLogger } from '@app/logger/app-logger.service';
import { UserRegisteredEvent } from '../auth.service';

/**
 * Listens for the 'user.registered' event and sends a welcome email.
 * Decouples side effects from the core registration flow.
 */
@Injectable()
export class UserRegisteredListener {
  constructor(
    @Inject(MAIL_SERVICE) private readonly mail: IMailService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext(UserRegisteredListener.name);
  }

  @OnEvent('user.registered', { async: true })
  async handleUserRegistered(event: UserRegisteredEvent): Promise<void> {
    this.logger.info('Handling user.registered event', { userId: event.user.id });
    await this.mail.sendWelcome(event.user.email, event.user.firstName);
  }
}
