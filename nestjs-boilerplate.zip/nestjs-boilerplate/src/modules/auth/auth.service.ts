import {
  Injectable,
  ConflictException,
  UnauthorizedException,
  BadRequestException,
  Inject,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { v4 as uuidv4 } from 'uuid';
import { UsersService } from '@modules/users/users.service';
import { FirebaseService } from '@app/firebase/firebase.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ForgotPasswordDto } from './dto/forgot-password.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { Token, TokenType } from './entities/token.entity';
import { User } from '@modules/users/entities/user.entity';
import { comparePassword, hashPassword } from '@common/utils/hash.util';
import { MAIL_SERVICE, IMailService } from '@app/mail/interfaces/mail.interface';

export class UserRegisteredEvent {
  constructor(public readonly user: User) {}
}

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly eventEmitter: EventEmitter2,
    private readonly firebaseService: FirebaseService,
    @InjectRepository(Token) private readonly tokenRepo: Repository<Token>,
    @Inject(MAIL_SERVICE) private readonly mail: IMailService,
  ) {}

  // ── Register ────────────────────────────────────────────────────────────────

  async register(dto: RegisterDto) {
    const existing = await this.usersService.findByEmail(dto.email);
    if (existing) throw new ConflictException('auth.register.email_taken');

    const user = await this.usersService.create(dto);

    // Send email verification
    const verifyToken = await this.createToken(user, TokenType.EMAIL_VERIFICATION, 24);
    await this.mail.sendEmailVerification(user.email, verifyToken.token);

    this.eventEmitter.emit('user.registered', new UserRegisteredEvent(user));

    return { user, ...this.issueTokenPair(user) };
  }

  // ── Login ───────────────────────────────────────────────────────────────────

  async login(dto: LoginDto) {
    const user = await this.usersService.findByEmail(dto.email);
    if (!user?.password) throw new UnauthorizedException('auth.login.invalid_credentials');

    const valid = await comparePassword(dto.password, user.password);
    if (!valid) throw new UnauthorizedException('auth.login.invalid_credentials');
    if (!user.isActive) throw new UnauthorizedException('auth.login.account_deactivated');

    return { user, ...this.issueTokenPair(user) };
  }

  // ── Refresh tokens ──────────────────────────────────────────────────────────

  async refresh(rawToken: string) {
    const record = await this.tokenRepo.findOne({
      where: { token: rawToken, type: TokenType.REFRESH },
      relations: ['user'],
    });

    if (!record?.isValid) throw new UnauthorizedException('auth.token.invalid');

    // Rotate: revoke old, issue new pair
    record.used = true;
    await this.tokenRepo.save(record);

    return { user: record.user, ...this.issueTokenPair(record.user) };
  }

  async logout(rawToken: string): Promise<void> {
    await this.tokenRepo.update({ token: rawToken, type: TokenType.REFRESH }, { used: true });
  }

  // ── Email verification ──────────────────────────────────────────────────────

  async verifyEmail(rawToken: string): Promise<void> {
    const record = await this.tokenRepo.findOne({
      where: { token: rawToken, type: TokenType.EMAIL_VERIFICATION },
      relations: ['user'],
    });

    if (!record?.isValid) throw new BadRequestException('auth.token.invalid');

    await this.usersService.update(record.userId, { isEmailVerified: true });
    record.used = true;
    await this.tokenRepo.save(record);
  }

  // ── Password reset ──────────────────────────────────────────────────────────

  async forgotPassword(dto: ForgotPasswordDto): Promise<void> {
    const user = await this.usersService.findByEmail(dto.email);
    // Always return 200 — never leak whether an email exists
    if (!user) return;

    const record = await this.createToken(user, TokenType.PASSWORD_RESET, 1);
    const resetUrl = `${this.config.get('APP_URL')}/auth/reset-password?token=${record.token}`;
    await this.mail.sendPasswordReset(user.email, resetUrl);
  }

  async resetPassword(dto: ResetPasswordDto): Promise<void> {
    const record = await this.tokenRepo.findOne({
      where: { token: dto.token, type: TokenType.PASSWORD_RESET },
      relations: ['user'],
    });

    if (!record?.isValid) throw new BadRequestException('auth.token.invalid');

    const hashed = await hashPassword(dto.newPassword);
    await this.usersService.update(record.userId, { password: hashed });

    // Revoke all refresh tokens on password reset
    await this.tokenRepo.update(
      { userId: record.userId, type: TokenType.REFRESH, used: false },
      { used: true },
    );
    record.used = true;
    await this.tokenRepo.save(record);
  }

  // ── Firebase social auth ────────────────────────────────────────────────────

  async firebaseLogin(idToken: string) {
    const decoded = await this.firebaseService.verifyIdToken(idToken);

    const email = decoded.email ?? '';
    const nameParts = (decoded.name ?? '').split(' ');
    const firstName = nameParts[0] || '';
    const lastName = nameParts.slice(1).join(' ') || '';

    let user = await this.usersService.findByFirebaseUid(decoded.uid);

    if (!user && email) {
      user = await this.usersService.findByEmail(email);
      if (user) {
        user = await this.usersService.update(user.id, { firebaseUid: decoded.uid });
      }
    }

    if (!user) {
      user = await this.usersService.createFirebaseUser({
        firebaseUid: decoded.uid,
        email,
        firstName,
        lastName,
        avatar: decoded.picture,
      });
      this.eventEmitter.emit('user.registered', new UserRegisteredEvent(user));
    }

    return { user, ...this.issueTokenPair(user) };
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────

  private issueTokenPair(user: User) {
    const accessToken = this.jwtService.sign(
      { sub: user.id, email: user.email, role: user.role },
      { expiresIn: this.config.get('JWT_EXPIRATION', '15m') },
    );
    const rawRefresh = uuidv4();
    // Persist refresh token (fire & forget)
    this.createToken(user, TokenType.REFRESH, 24 * 7, rawRefresh);
    return { accessToken, refreshToken: rawRefresh };
  }

  private async createToken(
    user: User,
    type: TokenType,
    expiresInHours: number,
    rawToken = uuidv4(),
  ): Promise<Token> {
    const expiresAt = new Date(Date.now() + expiresInHours * 60 * 60 * 1000);
    const record = this.tokenRepo.create({
      token: rawToken,
      type,
      user,
      userId: user.id,
      expiresAt,
    });
    return this.tokenRepo.save(record);
  }
}
