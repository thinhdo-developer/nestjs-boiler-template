import { Inject, Injectable } from '@nestjs/common';
import {
  STORAGE_SERVICE,
  IStorageService,
  UploadedFile,
} from '@app/storage/interfaces/storage.interface';

@Injectable()
export class UploadService {
  constructor(@Inject(STORAGE_SERVICE) private readonly storage: IStorageService) {}

  async uploadImage(file: Express.Multer.File): Promise<UploadedFile> {
    return this.storage.upload(file, { folder: 'images', isPublic: true });
  }

  async uploadDocument(file: Express.Multer.File): Promise<UploadedFile> {
    return this.storage.upload(file, { folder: 'documents', isPublic: false });
  }

  async delete(key: string): Promise<void> {
    return this.storage.delete(key);
  }

  async getSignedUrl(key: string, expiresIn = 3600): Promise<{ url: string }> {
    const url = await this.storage.getSignedUrl(key, expiresIn);
    return { url };
  }
}
