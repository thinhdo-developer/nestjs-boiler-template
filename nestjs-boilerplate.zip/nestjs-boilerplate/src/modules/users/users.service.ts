import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { SocialLoginDto } from '@modules/auth/dto/social-auth.dto';
import { hashPassword } from '@common/utils/hash.util';
import { PaginationDto } from '@common/pagination/pagination.dto';
import { PaginatedResponse } from '@common/pagination/paginated-response.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,
  ) {}

  // ── Create ───────────────────────────────────────────────────────────────────

  async create(dto: CreateUserDto): Promise<User> {
    const hashedPassword = await hashPassword(dto.password);
    const user = this.usersRepository.create({ ...dto, password: hashedPassword });
    return this.usersRepository.save(user);
  }

  async createSocialUser(dto: SocialLoginDto): Promise<User> {
    const providerIdField = `${dto.provider}Id`;
    const user = this.usersRepository.create({
      email: dto.email,
      firstName: dto.firstName,
      lastName: dto.lastName,
      avatar: dto.avatar,
      [providerIdField]: dto.providerId,
    });
    return this.usersRepository.save(user);
  }

  async createFirebaseUser(data: {
    firebaseUid: string;
    email: string;
    firstName: string;
    lastName: string;
    avatar?: string;
  }): Promise<User> {
    const user = this.usersRepository.create({
      firebaseUid: data.firebaseUid,
      email: data.email,
      firstName: data.firstName,
      lastName: data.lastName,
      avatar: data.avatar,
      isEmailVerified: true,
    });
    return this.usersRepository.save(user);
  }

  // ── Read ─────────────────────────────────────────────────────────────────────

  async findAll(pagination: PaginationDto): Promise<PaginatedResponse<User>> {
    const [data, total] = await this.usersRepository.findAndCount({
      skip: (pagination.page - 1) * pagination.limit,
      take: pagination.limit,
      order: { createdAt: 'DESC' },
    });
    return new PaginatedResponse(data, total, pagination.page, pagination.limit);
  }

  async findOne(id: string): Promise<User> {
    const user = await this.usersRepository.findOne({ where: { id } });
    if (!user) throw new NotFoundException(`User #${id} not found`);
    return user;
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { email } });
  }

  async findByFirebaseUid(uid: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { firebaseUid: uid } });
  }

  async findByProviderId(provider: 'google' | 'github', providerId: string): Promise<User | null> {
    const field = provider === 'google' ? 'googleId' : 'githubId';
    return this.usersRepository.findOne({ where: { [field]: providerId } });
  }

  // ── Update ───────────────────────────────────────────────────────────────────

  async update(id: string, dto: UpdateUserDto | Record<string, any>): Promise<User> {
    const user = await this.findOne(id);
    Object.assign(user, dto);
    return this.usersRepository.save(user);
  }

  // ── Delete ───────────────────────────────────────────────────────────────────

  async remove(id: string): Promise<void> {
    const user = await this.findOne(id);
    await this.usersRepository.softRemove(user);
  }
}
