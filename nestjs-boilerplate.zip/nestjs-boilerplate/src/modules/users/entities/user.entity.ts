import { Entity, Column } from 'typeorm';
import { Exclude } from 'class-transformer';
import { Role } from '@common/decorators/roles.decorator';
import { BaseEntity } from '@common/entities/base.entity';

@Entity('users')
export class User extends BaseEntity {
  @Column({ unique: true })
  email: string;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column({ nullable: true })
  @Exclude()
  password?: string;

  @Column({ type: 'enum', enum: Role, default: Role.USER })
  role: Role;

  @Column({ default: true })
  isActive: boolean;

  @Column({ default: false })
  isEmailVerified: boolean;

  @Column({ nullable: true })
  avatar?: string;

  // ── Social auth ─────────────────────────────────────────────────────────────

  @Column({ nullable: true, unique: true })
  firebaseUid?: string;


  get fullName(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  get isSocialAccount(): boolean {
    return !this.password;
  }
}
