import { Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as admin from 'firebase-admin';
import { DecodedIdToken } from 'firebase-admin/auth';
import { AppLogger } from '@app/logger/app-logger.service';

@Injectable()
export class FirebaseService implements OnModuleInit {
  private app: admin.app.App;

  constructor(
    private readonly config: ConfigService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext(FirebaseService.name);
  }

  onModuleInit() {
    // const serviceAccountPath = this.config.get<string>('FIREBASE_SERVICE_ACCOUNT_PATH');

    // if (serviceAccountPath) {
    //   // eslint-disable-next-line @typescript-eslint/no-require-imports
    //   const serviceAccount = require(serviceAccountPath);
    //   this.app = admin.initializeApp({
    //     credential: admin.credential.cert(serviceAccount),
    //   });
    // } else {
    //   this.app = admin.initializeApp({
    //     projectId: this.config.get<string>('FIREBASE_PROJECT_ID'),
    //   });
    // }

    // this.logger.info('Firebase Admin initialized', {
    //   projectId: this.app.options.projectId,
    // });
  }

  async verifyIdToken(idToken: string): Promise<DecodedIdToken> {
    return this.app.auth().verifyIdToken(idToken);
  }
}
