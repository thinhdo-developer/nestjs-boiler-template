import { AcceptLanguageResolver, HeaderResolver, QueryResolver } from 'nestjs-i18n';
import * as path from 'path';

/**
 * i18n configuration.
 * Language is resolved in order:
 *   1. ?lang= query param
 *   2. Accept-Language header
 *   3. x-custom-lang header
 *   4. Falls back to 'en'
 */
export const i18nConfig = {
  fallbackLanguage: 'en',
  loaderOptions: {
    path: path.join(__dirname, '/translations'),
    watch: true,
  },
  resolvers: [
    { use: QueryResolver, options: ['lang'] },
    AcceptLanguageResolver,
    new HeaderResolver(['x-custom-lang']),
  ],
};
