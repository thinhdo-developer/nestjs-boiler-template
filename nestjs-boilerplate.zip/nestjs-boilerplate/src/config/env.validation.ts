import * as Joi from 'joi';

/**
 * Joi schema for environment variable validation.
 * App crashes at startup if any required variable is missing or has wrong type.
 * This prevents silent runtime failures from misconfigured deployments.
 */
export const envValidationSchema = Joi.object({
  // App
  NODE_ENV: Joi.string().valid('development', 'test', 'production').default('development'),
  PORT: Joi.number().default(3000),
  API_PREFIX: Joi.string().default('api/v1'),
  SWAGGER_ENABLED: Joi.boolean().default(true),

  // Database
  DB_HOST: Joi.string().required(),
  DB_PORT: Joi.number().default(5432),
  DB_USERNAME: Joi.string().required(),
  DB_PASSWORD: Joi.string().required(),
  DB_NAME: Joi.string().required(),

  // JWT
  JWT_SECRET: Joi.string().min(32).required(),
  JWT_EXPIRATION: Joi.string().default('7d'),

  // Firebase
  FIREBASE_PROJECT_ID: Joi.string().required(),
  FIREBASE_SERVICE_ACCOUNT_PATH: Joi.string().optional(),

  // Mailer
  MAIL_HOST: Joi.string().optional(),
  MAIL_PORT: Joi.number().default(587),
  MAIL_USER: Joi.string().optional(),
  MAIL_PASSWORD: Joi.string().optional(),
  MAIL_FROM: Joi.string().email().optional(),
}).options({ allowUnknown: true }); // don't fail on extra vars
