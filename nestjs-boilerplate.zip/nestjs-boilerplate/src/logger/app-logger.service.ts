import { Injectable, Scope } from '@nestjs/common';
import { PinoLogger } from 'nestjs-pino';

/**
 * Thin wrapper around PinoLogger with context support.
 * Inject this instead of NestJS's built-in Logger for structured logging.
 *
 * @example
 * constructor(private readonly logger: AppLogger) {
 *   this.logger.setContext('UsersService');
 * }
 *
 * this.logger.info('User created', { userId });
 * this.logger.error('Failed to create user', { error, dto });
 */
@Injectable({ scope: Scope.TRANSIENT })
export class AppLogger {
  private context?: string;

  constructor(private readonly pino: PinoLogger) {}

  setContext(context: string): this {
    this.context = context;
    this.pino.setContext(context);
    return this;
  }

  info(message: string, meta?: Record<string, unknown>): void {
    this.pino.info({ context: this.context, ...meta }, message);
  }

  error(
    message: string,
    errorOrMeta?: Error | Record<string, unknown>,
    meta?: Record<string, unknown>,
  ): void {
    if (errorOrMeta instanceof Error) {
      this.pino.error({ context: this.context, err: errorOrMeta, ...meta }, message);
    } else {
      this.pino.error({ context: this.context, ...errorOrMeta }, message);
    }
  }

  warn(message: string, meta?: Record<string, unknown>): void {
    this.pino.warn({ context: this.context, ...meta }, message);
  }

  debug(message: string, meta?: Record<string, unknown>): void {
    this.pino.debug({ context: this.context, ...meta }, message);
  }

  trace(message: string, meta?: Record<string, unknown>): void {
    this.pino.trace({ context: this.context, ...meta }, message);
  }
}
