import { Global, Module } from '@nestjs/common';
import { LoggerModule as PinoLoggerModule } from 'nestjs-pino';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { createPinoConfig } from './pino.config';
import { AppLogger } from './app-logger.service';

/**
 * Global logger module — import once in AppModule.
 * Provides AppLogger for injection anywhere in the app.
 * Also registers pino-http middleware for automatic HTTP request logging.
 */
@Global()
@Module({
  imports: [
    PinoLoggerModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const nodeEnv = configService.get<string>('app.nodeEnv', 'development');
        return createPinoConfig(nodeEnv);
      },
    }),
  ],
  providers: [AppLogger],
  exports: [AppLogger],
})
export class LoggerModule {}
