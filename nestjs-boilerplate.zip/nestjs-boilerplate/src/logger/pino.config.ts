import { Params } from 'nestjs-pino';

/**
 * Pino logger configuration for nestjs-pino.
 *
 * Dev  → pino-pretty (human-readable, colorized)
 * Prod → raw JSON (pipe to your log aggregator: Datadog, ELK, Loki, etc.)
 *        e.g.  node dist/main | pino-pretty    (local inspection)
 *              node dist/main >> /var/log/app.log   (file, then ship with agent)
 */
export function createPinoConfig(nodeEnv: string): Params {
  const isProduction = nodeEnv === 'production';

  return {
    pinoHttp: {
      // Log level
      level: isProduction ? 'info' : 'debug',

      // Dev: pretty-print; Prod: raw JSON (fastest, no serialization overhead)
      transport: isProduction
        ? undefined
        : {
            target: 'pino-pretty',
            options: {
              colorize: true,
              singleLine: false,
              translateTime: 'SYS:yyyy-mm-dd HH:MM:ss',
              ignore: 'pid,hostname',
            },
          },

      // Redact sensitive fields from logs automatically
      redact: {
        paths: ['req.headers.authorization', 'req.body.password', 'req.body.token'],
        censor: '[REDACTED]',
      },

      // Custom request serializer — keep logs lean
      serializers: {
        req(req) {
          return {
            id: req.id,
            method: req.method,
            url: req.url,
            correlationId: req.headers?.['x-correlation-id'],
          };
        },
        res(res) {
          return { statusCode: res.statusCode };
        },
      },

      // Auto-log every request; set false to log manually
      autoLogging: true,

      // Attach correlation ID to every log line
      customProps: (req: any) => ({
        correlationId: req['correlationId'],
      }),

      // Custom log levels for HTTP status codes
      customLogLevel: (_req, res, err) => {
        if (res.statusCode >= 500 || err) return 'error';
        if (res.statusCode >= 400) return 'warn';
        return 'info';
      },
    },
  };
}
