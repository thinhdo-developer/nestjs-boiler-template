/**
 * Database seed script.
 * Usage: npx ts-node -r tsconfig-paths/register src/database/seed.ts
 * Or via npm: npm run seed
 */
import 'reflect-metadata';
import { AppDataSource } from './data-source';
import { UserSeeder } from './seeders/user.seeder';

const seeders = [
  new UserSeeder(),
  // Add more seeders here in order
];

async function main() {
  console.log('🌱 Connecting to database...');
  await AppDataSource.initialize();

  try {
    for (const seeder of seeders) {
      await seeder.seed(AppDataSource);
    }
    console.log('✅ All seeders completed successfully');
  } finally {
    await AppDataSource.destroy();
  }
}

main().catch((err) => {
  console.error('❌ Seeding failed:', err);
  process.exit(1);
});
