import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { BaseSeeder } from './base.seeder';
import { User } from '@modules/users/entities/user.entity';
import { Role } from '@common/decorators/roles.decorator';

export class UserSeeder extends BaseSeeder {
  async run(dataSource: DataSource): Promise<void> {
    const repo = dataSource.getRepository(User);

    const hash = await bcrypt.hash('Admin@12345', 10);

    const seeds: Partial<User>[] = [
      {
        email: 'admin@example.com',
        firstName: 'Admin',
        lastName: 'User',
        password: hash,
        role: Role.ADMIN,
        isActive: true,
        isEmailVerified: true,
      },
      {
        email: 'user@example.com',
        firstName: 'Regular',
        lastName: 'User',
        password: hash,
        role: Role.USER,
        isActive: true,
        isEmailVerified: true,
      },
    ];

    // upsert — safe to re-run (idempotent)
    await repo.upsert(seeds as User[], {
      conflictPaths: ['email'],
      skipUpdateIfNoValuesChanged: true,
    });

    this.logger.log(`Seeded ${seeds.length} users`);
  }
}
