import { DataSource } from 'typeorm';
import { Logger } from '@nestjs/common';

/**
 * Base class for all seeders.
 *
 * @example
 * export class UserSeeder extends BaseSeeder {
 *   async run(dataSource: DataSource): Promise<void> {
 *     const repo = dataSource.getRepository(User);
 *     await repo.upsert([...], ['email']);
 *   }
 * }
 */
export abstract class BaseSeeder {
  protected readonly logger = new Logger(this.constructor.name);

  abstract run(dataSource: DataSource): Promise<void>;

  async seed(dataSource: DataSource): Promise<void> {
    this.logger.log(`Running seeder: ${this.constructor.name}`);
    try {
      await this.run(dataSource);
      this.logger.log(`✓ ${this.constructor.name} completed`);
    } catch (err) {
      this.logger.error(`✗ ${this.constructor.name} failed`, err);
      throw err;
    }
  }
}
