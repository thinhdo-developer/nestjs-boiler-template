/**
 * Ensures required env exists before AppModule (and Joi) loads in e2e specs.
 * CI sets these via workflow `env`; locally defaults target docker-compose Postgres.
 */
process.env.NODE_ENV ??= 'development';
process.env.DB_HOST ??= '127.0.0.1';
process.env.DB_PORT ??= '5432';
process.env.DB_USERNAME ??= 'postgres';
process.env.DB_PASSWORD ??= 'postgres';
process.env.DB_NAME ??= 'nestjs_db';
process.env.JWT_SECRET ??= 'local-e2e-jwt-secret-32chars-min!!';
process.env.CACHE_DRIVER ??= 'memory';
process.env.FIREBASE_PROJECT_ID ??= 'test-project';
